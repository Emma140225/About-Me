# 🧮 Taschenrechner 2.2 - Modular

Ein objektorientienter Taschenrechner mit GUI, entwickelt mit Python und Tkinter.

## ✨ Features

- **Grundrechenarten**: +, -, *, /, %, //
- **Erweiterte Funktionen**: x², √, xⁿ, π
- **3 Speicherplätze**: M1, M2, M3 mit Rechtsklick-Speicherung
- **6 Themes**: Light, Dark, Blue, Red, Green, Purple
- **Tastatur-Support**: Eingabe über Tastatur + Enter-Taste
- **Modulare Architektur**: Saubere Code-Aufteilung
- **Verlauf-Manager**: Optional zuschaltbare Verlaufsübersicht

🎮 Bedienung
- Eingabe: Klicke Buttons oder verwende die Tastatur
- Berechnen: = Button oder Enter-Taste
- Löschen: C Button
- Speicher: Linksklick = Abrufen, Rechtsklick = Speichern
- Themes: Menü → Design → Theme auswählen

👩‍💻 Entwicklung
Autorin: Emma Paulus
Version: 2.2
Datum: September 2025
Architektur: Objektorientiert
Entwicklungszeit: ~40 Stunden

📄 Lizenz
© 2025 Emma Paulus - Entwickelt mit ❤️ und Python