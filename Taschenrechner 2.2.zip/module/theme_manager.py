from tkinter import *
from tkinter import ttk


class ThemeManager:
    #Verwaltet alle verfügbaren Themes für den Taschenrechner
    #Neue können bisher nur über den Code hinzugefügt werden
    
    def __init__(self):
        self.themes = {
        "light": {
            "bg": "#ffffff",
            "fg": "#000000",
            "button_bg": "#f0f0f0",
            "button_fg": "#000000",
            "entry_bg": "#f8f9fa",
            "entry_fg": "#000000",
            "accent": "#0078d4",
            "tooltip_bg": "#lightyellow",
            # =-Button Hervorhebung
            "equals_bg": "#28a745",     
            "equals_fg": "#ffffff",     
            "equals_hover": "#34ce57",     
            "equals_pressed": "#218838"    
        },
        "dark": {
            "bg": "#2b2b2b",
            "fg": "#ffffff", 
            "button_bg": "#404040",
            "button_fg": "#ffffff",
            "entry_bg": "#3c3c3c",
            "entry_fg": "#ffffff",
            "accent": "#0078d4",
            "tooltip_bg": "#444444",
            # =-Button Hervorhebung
            "equals_bg": "#ff6b35",     
            "equals_fg": "#ffffff",
            "equals_hover": "#ff8c5a",    
            "equals_pressed": "#e55a2b"    
        },
        "blue": {
            "bg": "#1e3a8a",
            "fg": "#ffffff",
            "button_bg": "#3b82f6",
            "button_fg": "#ffffff",
            "entry_bg": "#dbeafe",
            "entry_fg": "#1e40af",                
            "accent": "#60a5fa",
            "tooltip_bg": "#3b82f6",
            # =-Button Hervorhebung
            "equals_bg": "#fbbf24",        
            "equals_fg": "#1e40af",     
            "equals_hover": "#fcd34d",    
            "equals_pressed": "#f59e0b"   
        },
        "red": {
            "bg": "#991b1b",
            "fg": "#ffffff",
            "button_bg": "#dc2626",
            "button_fg": "#ffffff",
            "entry_bg": "#fee2e2",
            "entry_fg": "#991b1b",
            "accent": "#f87171",
            "tooltip_bg": "#dc2626",
            # =-Button Hervorhebung
            "equals_bg": "#10b981",       
            "equals_fg": "#ffffff",
            "equals_hover": "#34d399",     
            "equals_pressed": "#059669"    
        },
        "green": {
            "bg": "#166534",
            "fg": "#ffffff",
            "button_bg": "#16a34a",
            "button_fg": "#ffffff",
            "entry_bg": "#dcfce7",
            "entry_fg": "#166534",
            "accent": "#4ade80",
            "tooltip_bg": "#16a34a",
            # =-Button Hervorhebung
            "equals_bg": "#2563eb",      
            "equals_fg": "#ffffff",
            "equals_hover": "#3b82f6",    
            "equals_pressed": "#1d4ed8"   
        },
        "purple": {
            "bg": "#581c87",
            "fg": "#ffffff",
            "button_bg": "#9333ea",
            "button_fg": "#ffffff",
            "entry_bg": "#f3e8ff",
            "entry_fg": "#581c87",
            "accent": "#c084fc",
            "tooltip_bg": "#9333ea",
            # =-Button Hervorhebung
            "equals_bg": "#eab308",        
            "equals_fg": "#581c87",       
            "equals_hover": "#facc15",    
            "equals_pressed": "#ca8a04"  
        }
    }
    
    def get_theme(self, theme_name):
        #Theme nach Name abrufen
        return self.themes.get(theme_name, self.themes["light"])
    
    def get_available_themes(self):
        #Liste aller verfügbaren Themes
        return list(self.themes.keys())
  