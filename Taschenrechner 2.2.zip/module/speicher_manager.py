from tkinter import *
from tkinter import ttk


class SpeicherManager:
    #Verwaltet die Speicher-Funktionalität des Taschenrechners
    
    def __init__(self, anzahl_speicher=3):
        self.anzahl_speicher = anzahl_speicher
        # Dynamisch Speicher erstellen
        self.speicher = [0.0] * anzahl_speicher
        
    def set_update_callback(self, callback):
        #Setzt Callback für GUI-Updates
        self.update_callback = callback

    def _notify_update(self):
        #Benachrichtigt GUI über Änderungen
        if self.update_callback:
            self.update_callback()
    
    def speicher_setzen(self, nummer, wert):
        #Wert in Speicher setzen
        if 1 <= nummer <= self.anzahl_speicher:
            try:
                self.speicher[nummer - 1] = float(wert)
                return True
            except (ValueError, TypeError):
                return False
        return False
    
    def speicher_abrufen(self, nummer):
        #Wert aus Speicher abrufen
        if 1 <= nummer <= self.anzahl_speicher:
            return self.speicher[nummer - 1]
        return 0.0
    
    def speicher_löschen(self, nummer=None):
        #Speicher löschen - bestimmten oder alle
        if nummer is None:
            # Alle Speicher löschen
            self.speicher = [0.0] * self.anzahl_speicher
        elif 1 <= nummer <= self.anzahl_speicher:
            # Bestimmten Speicher löschen
            self.speicher[nummer - 1] = 0.0

        self._notify_update()

    def ist_speicher_leer(self, nummer):
        #Prüfen ob Speicher leer ist
        return self.speicher_abrufen(nummer) == 0.0
    
    def speicher_anzeige_text(self, nummer, max_länge=6):
        #Formatierter Text für Button-Anzeige
        wert = self.speicher_abrufen(nummer)
        if wert == 0.0:
            return f"M{nummer}: 0"
        else:
            # Mit 2 Dezimalstellen formatieren
            wert_str = f"{wert:.2f}".replace(".", ",")
            return f"M{nummer}: {wert_str[:max_länge]}"
    
    def get_alle_speicher(self):
        #Alle Speicherwerte zurückgeben
        return self.speicher.copy()
