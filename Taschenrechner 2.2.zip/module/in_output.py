from tkinter import *
from tkinter import ttk
from .tooltip import Tooltip

class button_factory:
    #Konfiguration aller Button
    def __init__(self, taschenrechner_instanz, parent=None):
        self.rechner = taschenrechner_instanz
        self.parent = parent if parent else taschenrechner_instanz.fenster
        self.buttons = {}
        self.button_configs = self.get_button_configuration()

    def get_button_configuration(self):
        return {
            "numbers": {
                "style": "Themed.TButton",
                "tooltip_prefix": "Zahl eingeben",
                "callback": lambda x: self.rechner.zeichen_einfügen(x)
            },
            "operators": {
                "style": "Operator.TButton",
                "tooltip_prefix": "Operator",
                "callback": lambda x: self.rechner.zeichen_einfügen(x)
            },
            "functions": {
                "style": "Function.TButton",
                "tooltip_prefix": "Funktion: "
            },
            "memory": {
                "style": "Memory.TButton",
                "tooltip_prefix": "Speichern: "
            },
            "equals": {
                "style": "Equals.TButton",
                "tooltip_prefix": "Berechnung ausführen"
            }
        }


    #Zahlen Button
    def zahlen_button(self):
        #Erstellen der Button 0-9 und Komma
        numbers = [
            ('0', '0'), ('1', '1'), ('2', '2'), ('3', '3'), ('4', '4'),
            ('5', '5'), ('6', '6'), ('7', '7'), ('8', '8'), ('9', '9'),
            (',', ',')
        ]

        for text, value in numbers:
            key = f"zahl_{value}" if value.isdigit() else "zahl_komma"
            self.buttons[key] = self.butten_erstellen(
                text=text,
                command=lambda v=value: self.rechner.gui_manager.eingabe.zeichen_einfügen(v),
                button_type="numbers",
            )

    #Operator Button
    def operator_button(self):
        #Erstellen aller Operator Button
        #Format der operators ('text', 'value', 'Tooltip')
        operators = [
            ('+', '+', 'Addition'),
            ('-', '-', 'Subtraktion'), 
            ('*', '*', 'Multiplikation'),
            ('/', '/', 'Division'),
            ('//', '//', 'Ganzzahldivision'),
            ('%', '%', 'Modulo'),
            ('x²', self.rechner.berechnungs_engine.quadrat_berechnen, 'Quadrat'),
            ('xⁿ', '**', 'Potenz'),
            ('√', self.rechner.berechnungs_engine.wurzel_berechnen, 'Quadratwurzel'),
            ('π', '3.14159265', 'Pi-Konstante')
        ]

        for text, value, tooltip in operators:
            key = f"operator_{text.replace('/', 'divi').replace('*', 'multi')}"
            if text == "√":
                command = value
            elif text == "x²":
                command = value
            else:
                command = lambda v=value: self.rechner.gui_manager.eingabe.zeichen_einfügen(v)
            
            self.buttons[key] = self._create_button(
                text=text,
                command=command,
                button_type="operators",
                tooltip=tooltip
            )

    #Funktions Button
    def functions_button(self):
        #Erstellen der Funktions Button
        #Format der functions (text, command, tooltip)
        functions = [
            ("=", self.rechner.berechnen, "Eingabe ausführen"),
            ("C", self.rechner.gui_manager.eingabe.reset, "Eingabe löschen"),
            ("(", lambda: self.rechner.gui_manager.eingabe.zeichen_einfügen("("), "Klammer öffnen"),
            (")", lambda: self.rechner.gui_manager.eingabe.zeichen_einfügen(")"), "Klammer schließen")
        ]

        for text, command, tooltip in functions:

            if text == "=":
                button_type = "equals"
            else:
                button_type = "functions"

            key = f"function_{text.replace('=', 'gleich').replace('C', 'löschen')}"
            self.buttons[key] = self._create_button(
                text=text,
                command=command,
                button_type=button_type,
                tooltip=tooltip
            )

    #Speicher Button
    def speicher_button(self):
        #Erstellen der Speicher Button, Menge wird vom Speicher Manager geladen
        anzahl = self.rechner.speicher_manager.anzahl_speicher
        for i in range (1, anzahl + 1):
            key = f"function_speicher{i}"
            
            # Command für Linksklick: Wert aus Speicher ins Eingabefeld
            def make_abrufen_command(num):
                return lambda: self.rechner.gui_manager.eingabe.zeichen_einfügen(str(
                    self.rechner.speicher_manager.speicher_abrufen(num)
                ))
            
            button = self._create_button(
                text=f"M{i}: 0",
                command=make_abrufen_command(i),
                button_type='memory',
                tooltip=f"Speicher {i}\nLinksklick: Wert ins Eingabefeld\nRechtsklick: Aktuellen Wert speichern"
            )
        
            # Rechtsklick: Aktuellen Eingabefeld-Wert im Speicher setzen
            def make_setzen_command(num, btn):  # Button als Parameter übergeben
                def setzen_command(event):
                    eingabe_text = self.rechner.gui_manager.eingabe.hole_text()
                    try:
                        wert = float(eingabe_text.replace(',', '.'))
                        self.rechner.speicher_manager.speicher_setzen(num, wert)

                        # Button-Text aktualisieren
                        neuer_text = self.rechner.speicher_manager.speicher_anzeige_text(num)
                        btn.configure(text=neuer_text)  # Verwende den übergebenen Button

                    except ValueError:
                        pass  # Ignoriere ungültige Eingaben
                return setzen_command

            #Rechte Maustaste -> <Button-3>
            button.bind("<Button-3>", make_setzen_command(i, button))  # Button mitübergeben
            self.buttons[key] = button

    def speicher_buttons_aktualisieren(self):
        #Aktualisiert alle Speicher-Button-Texte
        for i in range(1, self.rechner.speicher_manager.anzahl_speicher + 1):
            key = f"function_speicher{i}"
            if key in self.buttons:
                neuer_text = self.rechner.speicher_manager.speicher_anzeige_text(i)
                self.buttons[key].configure(text=neuer_text)

    #Erstellen aller Buttons auf einmal 
    def all_buttons(self):
        self.zahlen_button()
        self.operator_button()
        self.functions_button()
        self.speicher_button()

    
    def update_button_style(self):
        # Bei Themewechsel Styles korrekt neu zuweisen
        for key, button in self.buttons.items():
            if "zahl" in key:
                button.configure(style="Themed.TButton")
            elif "speicher" in key or "memory" in key:
                button.configure(style="Memory.TButton")
            elif "operator" in key:
                button.configure(style="Operator.TButton")
            elif "equals" in key or "gleich" in key:
                button.configure(style="Equals.TButton")
            elif "function" in key or "funktion" in key:
                button.configure(style="Function.TButton")
            else:
                button.configure(style="Themed.TButton")

    def _create_button(self, text, command, button_type="numbers", tooltip=None):
        #Zentrale Buttonerstellung
        config = self.button_configs[button_type]
    
        button = ttk.Button(
            self.parent,
            text=text,
            command=command,
            style=config['style']
        )
        
        if tooltip:
            Tooltip(button, tooltip)
        
        return button

    def butten_erstellen(self, text, command, button_type, tooltip=None):
        return self._create_button(text, command, button_type, tooltip)

    def get_buttons(self):
        #Buttons zurückgeben
        return self.buttons

class EingabeFeld:
    def __init__(self, taschenrechner_instanz, parent=None, style_name="Themed.TEntry"):
        self.rechner = taschenrechner_instanz
        self.parent = taschenrechner_instanz.fenster or parent
        self.style_name = style_name
        self.Entry = None
        self._textvar = StringVar()

    
    #Erstellung des Eingabefeldes
    def widget(self):
        if self.Entry is not None:
            return self.Entry
        
        parent = self.rechner.fenster
        style = self.style_name

        vcmd = (parent.register(self.zeichen_prüfen), "%P")
        self.Entry = ttk.Entry(
            parent,
            textvariable=self._textvar,
            justify="right",
            style=self.style_name,
            validate ="key",
            validatecommand=vcmd,
            )

        return self.Entry

    #Eingabefeld auslesen und Daten in Berechnungsengine schicken
    def hole_text(self):
        if self.Entry is None:
            self.widget()
        return self._textvar.get()

    #Daten aus Berechnungsengine abrufen und in Eingabefeld einfügen
    def setze_text(self, text:str):
        if self.Entry is None:
            self.widget()
        self._textvar.set(text)
    
    #Erlaubt Zeichen in Eingabefeld einfügen
    def zeichen_einfügen(self, zeichen:str):
        if self.Entry is None:
            self.widget()
        vorgeschlagen = self._textvar.get() + zeichen
        if not self.zeichen_prüfen(vorgeschlagen):
            return False
        self._textvar.set(vorgeschlagen)
        self.fokus()

    #Abfangen von falschen Eingaben, vorbeugen von Fehlern
    def zeichen_prüfen(self, vorgeschlagen: str):
        erlaubte_zeichen = "1234567890%()+-*/.,π"
        if vorgeschlagen == "":
            return True
        return all(c in erlaubte_zeichen for c in vorgeschlagen)

    #Löschen der Eingabe
    def reset(self):
        if self.Entry is None:
            self.widget()
        self._textvar.set("")
        self.fokus()
        
    #Sorgt das der Cursor immer im Eingabefeld verbleibt, egal ob Eingabe über Tastaur oder Button
    def fokus(self):
        if self.Entry is None:
            self.widget()
        self.Entry.focus_set()
        self.Entry.icursor(END)
