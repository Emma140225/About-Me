from tkinter import *
from tkinter import ttk

class Tooltip:
    def __init__(self, widget, text):
        self.widget = widget
        self.text = text
        self.widget.bind("<Enter>", self.on_enter)
        self.widget.bind("<Leave>", self.on_leave)
        self.tooltip = None

    #Tooltip anzeigen wenn der Mauszeiger den Button berührt
    def on_enter(self, event=None):
        x = self.widget.winfo_rootx() + 50
        y = self.widget.winfo_rooty() + 50
        self.tooltip = Toplevel(self.widget)
        self.tooltip.wm_overrideredirect(True)
        self.tooltip.wm_geometry(f"+{x}+{y}")
        label = Label(self.tooltip, text=self.text,
                    background="lightyellow",
                    relief="solid", borderwidth=1,
                    font=("Arial", 9))
        label.grid(row=0, column=0, sticky="nsew")

    #Tooltip entfernen wenn der Mauszeiger den Button verlässt
    def on_leave(self, event=None):
        if self.tooltip:
            self.tooltip.destroy()
            self.tooltip = None
