from tkinter import *
from tkinter import ttk
from datetime import datetime

class VerlaufManager:
    #Verwaltung der Verlaufshistorie

    def __init__(self, taschenrechner_instanz):
        self.rechner = taschenrechner_instanz
        self.verlauf = [] # Liste der Berechnungen
        self.verlauf_frame = None
        self.verlauf_listbox = None
        self.is_visible = False

    def verlauf_hinzufügen(self, eingabe, ergebnis):
        #Neue Berechnung zum Verlauf hinzufügen
        if eingabe and ergebnis and eingabe != ergebnis:
            timestamp = datetime.now().strftime("%H:%M:%S")
            entry = {
                'time': timestamp,
                'input': eingabe,
                'result':ergebnis,
                'display': f"{eingabe} = {ergebnis}"
            }

        self.verlauf.insert(0, entry)

        self.update_display()

    def velauf_panel_erstellen(self, parent):
        ##Fenster für den Verlauf erstellen
        self.verlauf_frame = Frame(
                                   self.rechner.fenster,
                                   bg=self.rechner.theme["bg"],
                                   width=300,
                                   relief="sunken",
                                   bd=1
                                   )
        

        self.verlauf_frame.grid_propagate(False)
        self.verlauf_frame.grid_rowconfigure(2, weight=1)  # Listbox-Frame expandiert
        self.verlauf_frame.grid_columnconfigure(0, weight=1)

        #Titel vom Fenster
        title_label = Label(
            self.verlauf_frame,
            text="📊 Verlauf",
            font=("Arial", 12, "bold"),
            bg=self.rechner.theme["bg"],
            fg=self.rechner.theme["fg"],
        )
        title_label.grid(row=0, column=0, pady=(0, 5), sticky="ew")

        info_label = Label(
            self.verlauf_frame,
            text="💡 Doppelklick zum Einfügen",
            font=("Arial", 9, "italic"),
            bg=self.rechner.theme["bg"],
            fg=self.rechner.theme["fg"],
            relief="flat"
        )
        info_label.grid(row=1, column=0, pady=(0, 8), sticky="ew")

        #Scrollbar und Frame erstellen
        listbox_frame = Frame(self.verlauf_frame)
        listbox_frame.grid(row=2, column=0, sticky="nsew", pady=(0, 5))

        listbox_frame.grid_rowconfigure(0, weight=1)
        listbox_frame.grid_columnconfigure(0, weight=1)

        #Scrollbar erstellen
        scrollbar = Scrollbar(listbox_frame)
        scrollbar.grid(row=0, column=1, sticky="ns")

        #Listbox erstellen
        self.verlauf_listbox = Listbox(
            listbox_frame,
            yscrollcommand=scrollbar.set,
            font=("Arial", 12),
            bg=self.rechner.theme["entry_bg"],
            fg=self.rechner.theme["entry_fg"],
            selectbackground=self.rechner.theme["accent"],
            relief="sunken",
            bd=1
        )

        #Scrollbar Konfiguration
        self.verlauf_listbox.config(yscrollcommand=scrollbar.set)
        self.verlauf_listbox.grid(row=0, column=0, sticky="nsew")

        #Scrollbar mit Listbox verknüpfen
        scrollbar.config(command=self.verlauf_listbox.yview)

        #Doppelklickevent hinzufügen: Ergebnis aus dem Verlauf ins Eingabefeld zurückholen
        self.verlauf_listbox.bind("<Double-Button-1>", self.verlauf_doppelklick)

        # #Button erstellen
        # self.verlauf_button_erstellen()

        return self.verlauf_frame
    
    def update_display(self):
        #Aktualisiert die Verlauf-Anzeige
        if self.verlauf_listbox:
            self.verlauf_listbox.delete(0, END)
            
            for entry in self.verlauf:
                # Format: [Zeit] Berechnung
                display_text = f"[{entry['time']}] {entry['display']}"
                self.verlauf_listbox.insert(END, display_text)

    def toggle_visibilty(self):
        #Ein und Ausblenden vom Verlauf
        if self.verlauf_frame:
            if self.is_visible:

                #Verlauf verstecken
                self.verlauf_frame.grid_remove()
                self.is_visible = False

                #Fenster verkleinern
                self.rechner.fenster.update_idletask()
                current_height = self.rechner.fenster.winfo_height()
                new_width = 420
                self.rechenr.fenster.geometry(f"{new_width}x{current_height}")

            else:
                #Verlauf anzeigen
                self.verlauf_frame.grid(row=0, column=10, rowspan=10, sticky="nsew", padx=(10, 0))
                self.is_visible = True

                #Fenster erweitern
                self.rechner.fenster.update_idletask()
                current_height = self.rechner.fenster.winfo_height()
                new_width = 420 + 320
                self.rechner.fenster.geometry(f"{new_width}x{current_height}")

    def verlauf_löschen(self):
        #Löscht den Verlauf komplett
        self.verlauf.clear()
        self.update_display()

    def verlauf_doppelklick(self, event):
    #Doppelklick auf Historie-Eintrag: Ergebnis ins Eingabefeld
        selection = self.verlauf_listbox.curselection()
        if selection:
            index = selection[0]
            if index < len(self.verlauf):
                result = self.verlauf[index]['result']
                self.rechner.gui_manager.eingabe.setze_text(result)
                self.rechner.gui_manager.fokus_setzen()

    def update_theme(self):
        #Aktualisiert das Design vom Verlauf
        if self.verlauf_frame:
            self.verlauf_frame.configure(bg=self.rechner.theme["bg"])
            
            for widget in self.verlauf_frame.winfo_children():
                if isinstance(widget, Label):
                    widget.configure(
                        bg=self.rechner.theme["bg"],
                        fg=self.rechner.theme["fg"]
                    )
        
        if self.verlauf_listbox:
            self.verlauf_listbox.configure(
                bg=self.rechner.theme["entry_bg"],
                fg=self.rechner.theme["entry_fg"],
                selectbackground=self.rechner.theme["accent"]
            )