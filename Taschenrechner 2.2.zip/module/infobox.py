from tkinter import *
from tkinter import ttk
from .engine import *


#Erstellt die Infobox die bei Hilfe -> Info erscheint
class infobox:
    def __init__(self, taschenrechner_instanz):
        self.rechner = taschenrechner_instanz
        self.fenster = None

    def info_box(self):

    #Aktuelles Theme mit einbeziehen
        theme = self.rechner.theme

    #Benutzerdefiniertes Info-Fenster mit anpassbarer Schriftart
        text = "\
┌─────────────────────────────┐\n\
│     TASCHENRECHNER 2.2      │\n\
└─────────────────────────────┘\n\n\
Autorin........: Emma Paulus\n\
Letzte Änderung: 04.09.2025\n\
Version........: 2.2 OOP Modular\n\
Architektur....: Objektorientiert\n\
Module.........: Aufgeteilt in seperate Dateien\n\
Dauer..........: ~40 Stunden\n\n\
★ FEATURES ★\n\
→ verschiedene Themes\n\
→ 3 Speicherplätze (M1-M3)\n\
→ Moderne GUI-Architektur\n\
→ Modulare Programm-Struktur\n\
→ Optional einblendbarer Verlaufsmanager\n\n\
© 2025 - Entwickelt mit Python & Tkinter"

        # Eigenes Dialog-Fenster erstellen
        info_dialog = Toplevel(self.rechner.fenster)
        info_dialog.title("📊 Programm-Information")
        info_dialog.geometry("450x500")
        info_dialog.resizable(False, False)

        #Theme auf Info-Fenster anwenden
        info_dialog.configure(bg=theme["bg"])
        
        #Schriftart anpassen
        text_label = Label(
            info_dialog, 
            text=text,
            font=("Consoas", 10),
            justify="left",
            bg=theme["entry_bg"],
            fg=theme["entry_fg"],
            padx=20,
            pady=20
        )
        text_label.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)
        
        # OK-Button
        ok_button = Button(
            info_dialog, 
            text="OK", 
            font=("Arial", 10, "bold"),      # ← Button-Schriftart
            command=info_dialog.destroy,
            bg=theme["accent"],
            fg=theme["button_fg"],
            width=10,
            relief="raised",
            bd=2
        )
        ok_button.grid(row=1, column=0, pady=10)
        
        # Dialog-Verhalten
        info_dialog.grid_rowconfigure(0, weight=1)
        info_dialog.grid_columnconfigure(0, weight=1)
        info_dialog.transient(self.rechner.fenster)
        info_dialog.grab_set()
        info_dialog.focus_set()
        
        # Mittig am Monitor anzeigen
        info_dialog.update_idletasks()
        x = (info_dialog.winfo_screenwidth() // 2) - (info_dialog.winfo_width() // 2)
        y = (info_dialog.winfo_screenheight() // 2) - (info_dialog.winfo_height() // 2)
        info_dialog.geometry(f"+{x}+{y}")
