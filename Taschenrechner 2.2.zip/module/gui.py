from tkinter import *
from tkinter import ttk
from .infobox import infobox
from .in_output import *
from .verlauf_manager import *

class menu_manager:
    #Menüpunkte initialisieren
    def __init__(self, taschenrechner_instanz):
        self.rechner = taschenrechner_instanz
        self.menubar = None
        self.datei_menu = None
        self.design_menu = None
        self.verlauf_menu = None
        self.help_menu = None

    
    def menubar_erstellen(self):
        #Komplette Menüleiste erstellen
        self.menubar = Menu(self.rechner.fenster)
        self.fenster = None
        self.rechner.fenster.config(menu=self.menubar)
        self.infobox = infobox(self.rechner)

        #Untermenüs
        self.datei_menu_erstellen()
        self.design_menu_erstellen()
        self.verlauf_menu_erstellen()
        self.help_menu_erstellen()

    def datei_menu_erstellen(self):
        #Datei Menü mit allen Funktionen
        self.datei_menu = Menu(self.menubar, tearoff=0)

        #Menüeinträge
        self.datei_menu.add_command(
            label="Speicher löschen",
            command=self.rechner.speicher_manager.speicher_löschen,
        )

        #Trennlinie für bessere Optik
        self.datei_menu.add_separator()

        #Beenden Schaltfläche hinzufügen
        self.datei_menu.add_command(
            label="Beenden",
            command=self.rechner.fenster.destroy
        )

        #Hinzufügen zur Hauptleiste
        self.menubar.add_cascade(label="Datei", menu=self.datei_menu)

    def design_menu_erstellen(self):
        #Design Menü mit allen Funktionen
        self.design_menu = Menu(self.menubar, tearoff=0)

        #Alle Designs vom Theme_Manager abrufen
        verfügbare_Designs = self.rechner.theme_manager.get_available_themes()

         #Menüeinträge automatisch aus vorhandenen Designs erstellen
        for design_name in verfügbare_Designs:
            self.design_menu.add_command(
                label=design_name.title(),
                command=lambda t=design_name: self.rechner.gui_manager.theme_wechseln(t)
            )
       
        #Hinzufügen zur Hauptleiste
        self.menubar.add_cascade(label="Design", menu=self.design_menu)
        

    def verlauf_menu_erstellen(self):
        #Verlaufsmenü erstellen
        self.verlauf_menu = Menu (self.menubar, tearoff=0) 

        self.verlauf_menu.add_command(
            label="Verlauf anzeigen/entfernen",
            command=self.rechner.gui_manager.verlauf_manager.toggle_visibilty
        )

        self.verlauf_menu.add_command(
            label="Verlauf löschen",
            command=self.rechner.gui_manager.verlauf_manager.verlauf_löschen
        )
        # Hinzufügen zur Hauptleiste
        self.menubar.add_cascade(label="Verlauf", menu=self.verlauf_menu)

    def help_menu_erstellen(self):
        #Hilfemenü mit allen funktionen
        self.help_menu = Menu(self.menubar, tearoff=0)

        self.help_menu.add_command(
            label="Info",
            command=lambda: self.infobox.info_box()
            )

        #Hinzufügen zur Hauptleiste
        self.menubar.add_cascade(label="Hilfe", menu=self.help_menu)

class GUI_manager:
    def __init__(self, taschenrechner_instanz):
        self.rechner = taschenrechner_instanz
        self.parent =taschenrechner_instanz.fenster
        self.style = None
        self.menu_manager = menu_manager(self.rechner)
        self.button_factory = button_factory(taschenrechner_instanz)
        self.eingabe = None
        #Button-Speicher nicht mehr als eigener Speicher
        self.buttons = {}
        self.speicher_buttons = {}
        self.verlauf_manager = VerlaufManager(self.rechner)



    def styles_initialisieren(self):
        # Style-Objekt an Fenster binden
        self.style = ttk.Style(self.rechner.fenster)

        # Aktuelles Theme vom Theme_Manager holen
        current_theme_name = self.rechner.current_theme_name
        theme = self.rechner.theme

        # Benutzung von 'clam', damit Farben für TTK-Buttons greifen
        try:
            self.style.theme_use("clam")
        except:
            pass

        self.rechner.fenster.config(background=theme["bg"])

        # Theme der Zahlen Button
        self.style.configure(
            "Themed.TButton",
            background=theme["button_bg"],
            foreground=theme["button_fg"],
            font=("Arial", 10, "bold"),
            padding=6
        )
        self.style.map(
            "Themed.TButton",
            background=[('active', theme["accent"]), ('pressed', theme["accent"])],
            foreground=[('active', theme["button_fg"]), ('pressed', theme["button_fg"])]
        )

        #Theme der Operator Button
        self.style.configure(
            "Operator.TButton",
            background=theme["button_bg"],
            foreground=theme["button_fg"],
            font=("Arial", 10, "bold"),
            padding=6
        )
        self.style.map(
            "Operator.TButton",
            background=[('active', theme["accent"]), ('pressed', theme["accent"])],
            foreground=[('active', theme["button_fg"]), ('pressed', theme["button_fg"])]
        )

        #Theme der Funktions Button
        self.style.configure(
            "Function.TButton",
            background=theme["button_bg"],
            foreground=theme["button_fg"],
            font=("Arial", 10, "bold"),
            padding=6
        )
        self.style.map(
            "Function.TButton",
            background=[('active', theme["accent"]), ('pressed', theme["accent"])],
            foreground=[('active', theme["button_fg"]), ('pressed', theme["button_fg"])]
        )

        # Theme der Speicher Button
        self.style.configure(
            "Memory.TButton",
            background=theme["accent"],
            foreground=theme["button_fg"],
            font=("Arial", 9, "bold")
        )

        # Theme des Eingabefeldes
        self.style.configure(
            "Themed.TEntry",
            fieldbackground=theme["entry_bg"],
            foreground=theme["entry_fg"],
            borderwidth=2,
            relief="sunken",
            font=("Arial", 22),
            padding=(10, 8),
            justify="right"
        )

        #Theme für den = Button
        self.style.configure(
            "Equals.TButton",
            background=theme["equals_bg"],
            foreground=theme["equals_fg"],
            font=("Arial", 10, "bold"),
            padding=6
        )

        #Interaktivelement für = Button
        self.style.map(
            "Equals.TButton",
            background=[
                ("active", theme["equals_hover"]),
                ("pressed", theme["equals_pressed"])
            ],
            foreground=[
                ("active", theme["equals_fg"]),
                ("pressed", theme["equals_fg"])
            ],
            relief=[
                ("pressed", "sunken"),
                ("active", "raised")
            ]
        )
    
    def theme_wechseln(self, theme_name):
        #Zugriff auf den Theme_Manager um das Design anzupassen
        self.rechner.current_theme_name = theme_name
        self.rechner.theme = self.rechner.theme_manager.get_theme(theme_name)
        
        self.current_theme_name = theme_name
        self.theme = self.rechner.theme

        # Theme auf alle Widgets anwenden
        self.widgets_theme_aktualisieren()

    def widgets_theme_aktualisieren(self):
        #Theme für alle Widgets aktualisieren
        self.theme = self.rechner.theme

        # Fenster Hintergrund
        self.rechner.fenster.configure(bg=self.theme["bg"])

        # TTK Styles neu erstellen
        self.styles_initialisieren()

        #Buttons Style aktualisieren
        self.button_factory.update_button_style()

        #Verlauf-Design aktualisieren
        self.verlauf_manager.update_theme()
  
    def gui_aufbauen(self):
            
        self.rechner.fenster.grid_columnconfigure(0, weight=1)

        #GUI Elemente generieren
        self.styles_initialisieren()
        self.menubar_erstellen()
        self.eingabe_erstellen_in_frame(self.rechner.fenster)
        self.buttons_erstellen()
        self.layout_anordnen()
        self.verlauf_manager.velauf_panel_erstellen(self.rechner)
        self.keyboard_bindings()
        self.fokus_setzen()

    def eingabe_erstellen_in_frame(self, parent_frame):
        #Eigener Frame für das Eingabefeld
        entry_frame = Frame(parent_frame)
        entry_frame.grid(row=0, column=0, sticky="ew", padx=8, pady=8)
        entry_frame.grid_rowconfigure(1, weight=1)
        entry_frame.grid_columnconfigure(0, weight=1)

        #Eingabefeld auf Rechner begrenzen
        self.eingabe = EingabeFeld(
            taschenrechner_instanz=self.rechner,
            parent=parent_frame,
            style_name="Themed.TEntry"
        )

        entry = self.eingabe.widget()
        entry.grid(row=0, column=0, columnspan=4, sticky="ew")

        for i in range(4):
            parent_frame.grid_columnconfigure(i, weight=1
                                              )

    def button_erstellen(self, text, command, button_type="numbers", tooltip=None):
        # Button-Konfiguration aus der Factory verwenden
        if hasattr(self, 'button_factory') and self.button_factory:
            config = self.button_factory.button_configs.get(button_type, 
                                                            self.button_factory.button_configs["numbers"])
            style = config['style']
        else:
            # Bei fehlerhaftem Zugriff, Buttons auf Standard Theme setzen
            style_map = {
                "numbers": "Themed.TButton",
                "operators": "Operator.TButton", 
                "functions": "Function.TButton",
                "memory": "Memory.TButton",
                "equals": "Equal.TButton"
            }
            style = style_map.get(button_type, "Themed.TButton")
        
        button = ttk.Button(self.rechner_frame, text=text, command=command, style=style)
        
        if tooltip:
            Tooltip(button, tooltip)
        return button

    def get_button_layout(self):
        #Konfiguration fürs Button Layout
        # Die Position ist in der Klammer angelegt und wird für die Positionierung abgerufen
        # Format: button_key: (row, column, padx, pady, ipadx, ipady)
        return {
        # Zeile 1
        "function_speicher1": (1, 0, 2, 2, 15, 8),
        "function_speicher2": (1, 1, 2, 2, 15, 8),
        "function_speicher3": (1, 2, 2, 2, 15, 8),
        "function_löschen": (1, 3, 2, 2, 15, 8),
        
        # Zeile 2
        "operator_x²": (2, 0, 2, 2, 15, 8),
        "operator_√": (2, 1, 2, 2, 15, 8),
        "operator_xⁿ": (2, 2, 2, 2, 15, 8),
        "operator_π": (2, 3, 2, 2, 15, 8),
        
        # Zeile 3
        "function_(": (3, 0, 2, 2, 15, 8),
        "function_)": (3, 1, 2, 2, 15, 8),
        "operator_%": (3, 2, 2, 2, 15, 8),
        "operator_dividivi": (3, 3, 2, 2, 15, 8),
        
        # Zahlenblock 3x3 Zeilen 4-6
        "zahl_7": (4, 0, 2, 2, 15, 8),
        "zahl_8": (4, 1, 2, 2, 15, 8),
        "zahl_9": (4, 2, 2, 2, 15, 8),
        
        "zahl_4": (5, 0, 2, 2, 15, 8),
        "zahl_5": (5, 1, 2, 2, 15, 8),
        "zahl_6": (5, 2, 2, 2, 15, 8),
        
        "zahl_1": (6, 0, 2, 2, 15, 8),
        "zahl_2": (6, 1, 2, 2, 15, 8),
        "zahl_3": (6, 2, 2, 2, 15, 8),
        
        # Zeile 7
        "zahl_0": (7, 0, 2, 2, 15, 8),
        "zahl_komma": (7, 1, 2, 2, 15, 8),
        "function_gleich": (7, 2, 2, 2, 15, 8),
        
        # Operatoren in der rechten Spalte
        "operator_divi": (4, 3, 2, 2, 15, 8),        # ÷
        "operator_multi": (5, 3, 2, 2, 15, 8),       # ×
        "operator_-": (6, 3, 2, 2, 15, 8),           # -
        "operator_+": (7, 3, 2, 2, 15, 8),           # +
    }

    # [Eingabefeld über alle 4 Spalten]
    # [M1] [M2] [M3] [C ]
    # [x²] [√ ] [x^n] [π ]
    # [( ] [) ] [% ] [//]
    # [7 ] [8 ] [9 ] [÷ ]
    # [4 ] [5 ] [6 ] [× ]
    # [1 ] [2 ] [3 ] [- ]
    # [0 ] [, ] [= ] [+ ]

    def layout_anordnen(self):
        #Anordnung der Button nach obiger Konfiguration
        layout = self.get_button_layout()
        for button_key, (row, col, padx, pady, ipadx, ipady) in layout.items():
            if button_key in self.buttons:
                self.buttons[button_key].grid(
                    row=row, column=col,
                    padx=padx, pady=pady,
                    ipadx=ipadx, ipady=ipady
                )

    def speicher_buttons_erstellen(self):
        #Speicher Button dynamisch erstellen (Auf dem Rechner sind aktuell nur 3 Sichtbar
        #aber theoretisch endlos erweiterbar)
        anzahl = self.rechner.speicher_manager.anzahl_speicher
        for i in range(1, anzahl+1):
            button = self.button_erstellen(
                text=f"M{i}: 0",
                command=lambda num=i: self.rechner.speicher_manager.speicher_abrufen(num),
                button_type="Memory",
                tooltip="Linksklick: Wert abrufen\nRechtsklick: Wert speichern"
            )
            button.bind("<Button-3>", lambda event, num=i: self.rechner.speicher_setzen(num))
            self.speicher_buttons[i]=button

    def keyboard_bindings(self):
        # Zusätzlich Enter-Taste direkt auf das Entry-Widget binden
        entry_widget = self.eingabe.widget()
        if entry_widget:
            entry_widget.bind("<Return>", lambda e: self.rechner.berechnen())
        
    def menubar_erstellen(self):
        # Menüleiste erstellen
        self.menu_manager.menubar_erstellen()
        
    def buttons_erstellen(self):
        # Alle Buttons erstellen
        self.button_factory.all_buttons()
        self.buttons = self.button_factory.get_buttons()
        
    def layout_anordnen(self):
        # Buttons anordnen
        layout = self.get_button_layout()
        for button_key, (row, col, padx, pady, ipadx, ipady) in layout.items():
            if button_key in self.buttons:
                self.buttons[button_key].grid(
                    row=row, column=col,
                    padx=padx, pady=pady,
                    ipadx=ipadx, ipady=ipady
                )
        
    def fokus_setzen(self):
        # Fokus auf Eingabefeld setzen
        self.eingabe.fokus()
