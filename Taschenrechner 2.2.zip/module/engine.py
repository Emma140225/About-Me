from tkinter import *
from tkinter import messagebox




import math
class BerechnungsEngine:
    def __init__(self, taschenrechner_instanz):
        self.rechner = taschenrechner_instanz
        self.Error = ErrorManager(taschenrechner_instanz)
        self.sichere_umgebung = self._erstelle_sichere_umgebung()
    
    def _erstelle_sichere_umgebung(self):
        #Definiert erlaubte Funktionen für eval
        return {
            '__builtins__': {},
            'abs': abs, 'round': round, 'min': min, 'max': max,
            'sin': math.sin, 'cos': math.cos, 'tan': math.tan,
            'sqrt': math.sqrt, 'log': math.log, 'log10': math.log10,
            'pi': math.pi, 'e': math.e, 'π': math.pi
        }
    
    def normalisiere_eingabe(self, eingabe):
        #Wandelt Eingabe in eval-fähige Form um
        # Komma zu Punkt 
        normalisiert = eingabe.replace(',', '.')
        # π Symbol ersetzen
        normalisiert = normalisiert.replace('π', 'pi')  # oder 'pi'
        # Weitere Normalisierungen...
        return normalisiert
    
    def berechne(self, eingabe):
        #Hauptberechnungsmethode
        try:
            normalisierte_eingabe = self.normalisiere_eingabe(eingabe)
            
            if not normalisierte_eingabe.strip():
                return ""
            
            ergebnis = eval(normalisierte_eingabe, self.sichere_umgebung)
            ergebnis_str = str(ergebnis)
        
        #Zum Verlauf hinzufügen
            self.rechner.gui_manager.verlauf_manager.verlauf_hinzufügen(
                eingabe, ergebnis_str
            )
            
            return ergebnis_str
            
        except ZeroDivisionError:
            self.Error.fehler("Division durch Null nicht möglich")
            return "Fehler"
        except SyntaxError:
            self.Error.fehler("Ungültige Eingabe")
            return "Fehler"
        except Exception as e:
            self.Error.aus_exception(e)
            return "Fehler"

    def wurzel_berechnen(self):
        #Direkte Wurzelberechnung bei drücken der Wurzeltaste
        eingabe = self.rechner.gui_manager.eingabe.hole_text().replace(",", ".")
        try:
            if eingabe:
                import math
                ergebnis = str(math.sqrt(float(eingabe))).replace(".", ",")
                self.rechner.gui_manager.eingabe.setze_text(ergebnis)
        except:
            pass


    def quadrat_berechnen(self):
        #Direkte Quadratberechnung bei drücken des Button X²
        try:
            eingabe = self.rechner.gui_manager.eingabe.hole_text().replace(",", ".")
            if eingabe:
                ergebnis = str(float(eingabe) ** 2).replace(".", ",")
                self.rechner.gui_manager.eingabe.setze_text(ergebnis)
        except:
            pass

class ErrorManager:
    def __init__(self, taschenrechner_instanz):
        self.rechner = taschenrechner_instanz

    def fehler(self, nachricht: str, titel: str = "Fehler"):
        messagebox.showinfo(title=titel, message=nachricht)

    def warnung(self, nachricht: str, titel: str = "Hinweis"):
        messagebox.showwarning(title=titel, message=nachricht)

    def info(self, nachricht: str, titel: str = "Info"):
        messagebox.showinfo(title=titel, message=nachricht)

    def aus_exception(self, exc: Exception):
        if isinstance(exc, ZeroDivisionError):
            self.fehler("❌ Durch 0 Dividieren funktioniert nicht.", "Fehler")
        elif isinstance(exc, SyntaxError):
            self.fehler("❌ Ungültiger Ausdruck.", "Fehler")
        else:
            self.fehler("❌ Fehler in der Berechnung", "Fehler")
